
-- --------------------------------------------------------

--
-- Table structure for table `category`
--
-- Creation: Aug 25, 2018 at 11:19 AM
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `cat_name` varchar(50) NOT NULL,
  `cat_image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `category`:
--

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_image`) VALUES
(1, 'smartphone', 'https://www.lg.com/au/images/smartphones/md05878255/gallery/V30-medium01.jpg');
