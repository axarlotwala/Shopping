
-- --------------------------------------------------------

--
-- Table structure for table `rating`
--
-- Creation: Sep 13, 2018 at 05:53 AM
--

DROP TABLE IF EXISTS `rating`;
CREATE TABLE `rating` (
  `rating_id` int(30) NOT NULL,
  `token` varchar(28) NOT NULL,
  `product_id` int(30) NOT NULL,
  `rating` float NOT NULL,
  `comment` varchar(500) NOT NULL,
  `rating_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `rating`:
--   `token`
--       `customer` -> `token`
--   `product_id`
--       `product` -> `product_id`
--

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`rating_id`, `token`, `product_id`, `rating`, `comment`, `rating_time`) VALUES
(1, 'MgDg9KUJPHZoEbiCqh5EKSud6nx1', 45, 3.5, 'ikipedia volunteers are special. They hail from all across the globe, representing every professional and personal experience one can imagine. They donate tons of hours per year to writing and editing Wikipedia. Without them, we would not exist.', '2018-09-15 08:54:30'),
(4, 'MgDg9KUJPHZoEbiCqh5EKSud6nx1', 32, 3.5, 'ikipedia volunteers are special. They hail from all across the globe, representing every professional and personal experience one can imagine. They donate tons of hours per year to writing and editing Wikipedia. Without them, we would not exist.', '2018-09-15 08:59:25'),
(11, 'NqVzQPifF2UOi1E251Fb5Xvzkqk2', 31, 3.2, 'good product', '2018-09-17 13:16:57'),
(12, 'sDaiU7Y9CRgwHUchEPt7eqixleg2', 35, 4, 'good product of skullkuendy very nice product I have great experience I am very happy thank shopping shallers..', '2018-09-17 17:03:18');
