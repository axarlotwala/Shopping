
-- --------------------------------------------------------

--
-- Table structure for table `test`
--
-- Creation: Sep 27, 2018 at 04:30 AM
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `id` varchar(28) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `age` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `test`:
--

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `name`, `age`) VALUES
('11141496945bac69add3afe', 'viewnew', 45),
('12103414775bac697b5ef14', 'view', 26),
('18465598015bac6a97beedb5bac6', 'uniquetrail', 60),
('39a9dc8b-c20e-11', 'vicesr', 26),
('6150380495bac6a0253a09', 'y1', 40),
('773c6740-c20e-11', 'neeel', 25),
('c089d2f2-c20e-11e8-9e12-68f7', 'arjun', 30);
