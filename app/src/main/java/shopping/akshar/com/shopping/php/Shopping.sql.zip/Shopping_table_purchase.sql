
-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--
-- Creation: Sep 15, 2018 at 08:19 AM
--

DROP TABLE IF EXISTS `purchase`;
CREATE TABLE `purchase` (
  `purchase_id` int(30) NOT NULL,
  `token` varchar(28) NOT NULL,
  `product_id` int(30) NOT NULL,
  `purchase_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `purchase`:
--   `product_id`
--       `product` -> `product_id`
--   `token`
--       `customer` -> `token`
--

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`purchase_id`, `token`, `product_id`, `purchase_date`) VALUES
(1, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 32, '2018-09-15 11:25:30'),
(2, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 27, '2018-09-15 11:43:29'),
(3, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 25, '2018-09-15 12:56:40'),
(4, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 42, '2018-09-15 17:21:30'),
(5, 'NqVzQPifF2UOi1E251Fb5Xvzkqk2', 31, '2018-09-17 13:16:27'),
(6, 'sDaiU7Y9CRgwHUchEPt7eqixleg2', 35, '2018-09-17 17:01:57'),
(7, 'sDaiU7Y9CRgwHUchEPt7eqixleg2', 24, '2018-09-17 17:10:47');
