
-- --------------------------------------------------------

--
-- Table structure for table `brand`
--
-- Creation: Aug 30, 2018 at 06:44 PM
--

DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `brand_id` varchar(30) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `brand_image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `brand`:
--

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand_id`, `brand_name`, `brand_image`) VALUES
('brand001', 'Mi', 'http://pluspng.com/img-png/xiaomi-png-file-xiaomi-logo-png-674.png'),
('brand0010', 'Samsung', 'http://pngimg.com/uploads/samsung_logo/samsung_logo_PNG12.png'),
('brand0011', 'Microsoft', 'http://pngimg.com/uploads/microsoft/microsoft_PNG18.png'),
('brand0012', 'Pixel', 'https://www.xda-developers.com/files/2017/10/Google-Pixel-2-Feature-Image-with-Shadow-Pink.png'),
('brand002', 'Lenovo', 'http://www.pngmart.com/files/4/Lenovo-Logo-PNG-Clipart.png'),
('brand003', 'Honor', 'https://media.carphonewarehouse.com/is/image/cpw2/honor-10-blue-l45?$Small$&fmt=png-alpha'),
('brand004', 'Moto G', 'https://d3mwk3f7r8fv9u.cloudfront.net/images/JrN-7qmMEBLvIZOnhsTiBoTJ.png'),
('brand005', 'One Plus', 'https://seeklogo.com/images/O/oneplus-logo-B6703954CF-seeklogo.com.png'),
('brand007', 'Oppo', 'https://logos-download.com/wp-content/uploads/2016/06/OPPO_logo-700x117.png'),
('brand008', 'Nokia', 'https://www.nokia.com/sites/default/files/styles/medium/public/media/nokia_logo_blue.png?itok=ok7Uwc1Q'),
('brand009', 'Vivo', 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Vivo_mobile_logo.png/800px-Vivo_mobile_logo.png');
