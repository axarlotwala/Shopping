
-- --------------------------------------------------------

--
-- Table structure for table `customer`
--
-- Creation: Aug 18, 2018 at 08:49 AM
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `token` varchar(28) NOT NULL,
  `cust_name` varchar(23) CHARACTER SET utf8 DEFAULT NULL,
  `cust_phoneno` varchar(17) CHARACTER SET utf8 DEFAULT NULL,
  `cust_address` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
  `cust_pincode` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
  `gender` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `cust_email` varchar(38) CHARACTER SET utf8 DEFAULT NULL,
  `cust_password` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
  `register_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `profile_photo` varchar(80) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `customer`:
--

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`token`, `cust_name`, `cust_phoneno`, `cust_address`, `cust_pincode`, `gender`, `cust_email`, `cust_password`, `register_date`, `profile_photo`) VALUES
('abcdefghijk', 'abcde', '9227923446', 'surat', '395009', 'male', 'ash@gmail.com', 'ASHVK', '2018-08-30 21:00:07', NULL),
('KhEZwPjfAwQI255tAdPY9hxdzym2', '', NULL, NULL, '', NULL, 'axarl@gmail.com', 'AXAR84880', '2018-08-25 18:37:05', NULL),
('MgDg9KUJPHZoEbiCqh5EKSud6nx1', 'usha', '8460790890', 'nanavat', '395006', NULL, 'ushalotwala@gmail.com', 'usha233', '2018-09-06 16:28:03', NULL),
('NqVzQPifF2UOi1E251Fb5Xvzkqk2', 'menew', '1234567890', 'varcha', '390445', NULL, 'menew@gmail.com', '1234567890', '2018-09-17 13:15:42', NULL),
('sDaiU7Y9CRgwHUchEPt7eqixleg2', 'fiveer new', '1234567890', 'any location', '123456', NULL, 'fivernew@gmail.com', 'fiveer1234', '2018-09-17 17:00:56', NULL),
('YLp0zUsL9kd6DBWIHH6oY228P013', NULL, NULL, NULL, NULL, NULL, 'axarlotwala@gmail.com', 'AXAR84880', '2018-08-30 17:17:00', NULL);
