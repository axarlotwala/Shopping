
-- --------------------------------------------------------

--
-- Table structure for table `cart`
--
-- Creation: Aug 24, 2018 at 05:47 PM
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int(30) NOT NULL,
  `token` varchar(28) NOT NULL,
  `product_id` int(30) NOT NULL,
  `cart_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `cart_qty` int(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `cart`:
--   `product_id`
--       `product` -> `product_id`
--   `token`
--       `customer` -> `token`
--

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `token`, `product_id`, `cart_date`, `cart_qty`) VALUES
(1, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 24, '2018-09-05 11:54:32', 0),
(2, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 25, '2018-09-06 10:27:23', 0),
(5, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 26, '2018-09-14 11:28:07', 0),
(12, 'KhEZwPjfAwQI255tAdPY9hxdzym2', 30, '2018-09-14 11:47:46', 0),
(13, 'sDaiU7Y9CRgwHUchEPt7eqixleg2', 35, '2018-09-17 17:01:19', 0);
