
-- --------------------------------------------------------

--
-- Table structure for table `image`
--
-- Creation: Sep 24, 2018 at 05:22 AM
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `id` int(30) NOT NULL,
  `url` varchar(256) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `image`:
--

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `url`, `name`) VALUES
(1, 'http://192.168.0.103/shopping/upload/1.png', 'axar'),
(2, 'http://192.168.0.103/shopping/upload/2.png', 'header'),
(3, 'http://192.168.0.103/shopping/upload/3.png', 'One Plus'),
(4, 'http://192.168.0.103/shopping/upload/4.png', 'Bages'),
(5, 'http://192.168.0.103/shopping/upload/5.jpg', 'Model Boys'),
(6, 'http://192.168.0.103/shopping/upload/6.png', 'Lady'),
(7, 'http://192.168.0.103/shopping/upload/eccbc87e4b5ce2fe28308fd9f2a7baf4.png', 'android'),
(8, 'http://192.168.0.103/shopping/upload/eccbc87e4b5ce2fe28308fd9f2a7baf4.jpeg', 'Lekh'),
(9, 'http://192.168.0.103/shopping/upload/9.jpg', 'bot'),
(11, 'http://192.168.0.103/shopping/upload/11.jpeg', 'paper'),
(12, 'http://192.168.0.103/shopping/upload/12.jpg', 'number plate'),
(13, 'http://192.168.0.103/shopping/upload/13.jpg', 'bracelet'),
(14, 'http://192.168.0.103/shopping/upload/14.jpg', 'me'),
(15, 'http://192.168.0.103/shopping/upload/15.jpg', 'a'),
(16, 'http://192.168.0.103/shopping/upload/16.jpg', 'logo'),
(17, 'http://192.168.0.103/shopping/upload/17.jpg', 'single watch');
