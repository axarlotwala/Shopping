
-- --------------------------------------------------------

--
-- Table structure for table `product`
--
-- Creation: Aug 24, 2018 at 01:31 PM
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `product_id` int(30) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_price` int(30) NOT NULL,
  `product_desc` varchar(500) NOT NULL,
  `product_image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONSHIPS FOR TABLE `product`:
--

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_price`, `product_desc`, `product_image`) VALUES
(24, 'sony watch', 300, 'new sonta brand new watch', 'http://pngimg.com/uploads/watches/watches_PNG9911.png'),
(25, 'Rado Watch', 1000, 'Rado new Brand Item Simple Watch', 'http://pngimg.com/uploads/watches/watches_PNG9899.png'),
(26, 'Nike Shoes', 1500, 'Blue Color Shoes', 'http://pngimg.com/uploads/men_shoes/men_shoes_PNG7478.png'),
(27, 'Natrag Mixer', 800, 'Natrag new Mixer', 'http://www.freedomcart.com/image/cache/mobile%20cases/Capture-700x700.PNG'),
(28, 'DSLR', 4500, '700 D 10X Zoom', 'https://images-na.ssl-images-amazon.com/images/I/81JD2fi1-AL._SX355_.jpg'),
(29, 'Matrix Watch', 2000, 'Skmei 1155BLUE Outdoor Sports Dual Time Watch - For Men', 'http://pngimg.com/uploads/watches/watches_PNG9907.png'),
(30, 'Canvas Red Shoes', 1500, 'new canvas puma shoes', 'https://image.dhgate.com/albu_269291508_00/1.0x0.jpg'),
(31, 'Black Funckey Shoes', 1000, 'Funckey shoes with hills', 'https://www.yuwise.com/uploads/6/7/8/2/67825553/s312814524695585102_p62_i6_w600.jpeg'),
(32, 'Solestick Glass', 800, 'Solestick Stamp Black Glass', 'http://images.clipartpanda.com/aviator-sunglasses-png-aviator-sunglasses-800x566.jpg'),
(33, 'Rayban Blue', 600, 'Rayban Blues Glass', 'https://4.imimg.com/data4/PI/XT/MY-11905953/ray-ban-sunglasses-500x500.jpg'),
(34, 'JBL BLUE', 1000, 'Jbl new Earphone', 'https://cdn8.bigcommerce.com/s-fa8ae9fe8j/content/pdp_images/1280x1280_351_1908.jpg'),
(35, 'SkullKunedy', 2000, 'Skull new small size earphone', 'https://d2211byn0pk9fi.cloudfront.net/spree/products/15384/product/A32330J1_TD01.jpg?1461132681'),
(36, 'Asus', 35000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5928.png'),
(37, 'Dell', 50000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5940.png'),
(38, 'Lenovo', 40000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5922.png'),
(39, 'Acer', 65000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5905.png'),
(40, 'Sony Vio', 32000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5926.png'),
(41, 'Macbook', 80000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5901.png'),
(42, 'Asus Notebook', 32000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5904.png'),
(43, 'Samsung', 45000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5908.png'),
(44, 'Lenovo Notepad', 65000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5922.png'),
(45, 'Acer Xpress', 192000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build quality, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5905.png'),
(46, 'Asus Vivo', 95000, 'XPS delivers the ultimate experience with the highest resolution displays, exceptional build qu;lity, unique materials and powerful features.', 'http://pngimg.com/uploads/laptop/laptop_PNG5919.png');
